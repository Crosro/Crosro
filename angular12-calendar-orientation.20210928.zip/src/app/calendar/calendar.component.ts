import {Component, ViewChild, AfterViewInit} from "@angular/core";
import {DayPilot, DayPilotCalendarComponent} from "daypilot-pro-angular";
import {DataService} from "./data.service";

@Component({
  selector: 'calendar-component',
  template: `<daypilot-calendar [config]="config" [events]="events" #calendar></daypilot-calendar>`,
  styles: [``]
})
export class CalendarComponent implements AfterViewInit {

  @ViewChild("calendar")
  calendar!: DayPilotCalendarComponent;

  events: any[] = [];

  landscape = window.matchMedia("(orientation: landscape)");
  smallWidth =  window.matchMedia("(max-width: 800px)");

  config: DayPilot.CalendarConfig = {
    viewType: "Week",
    cellHeight: 30,
    durationBarVisible: false,
    timeRangeSelectedHandling: "Enabled",
    onTimeRangeSelected: async (args) => {
      const modal = await DayPilot.Modal.prompt("Create a new event:", "Event 1");
      const dp = args.control;
      dp.clearSelection();
      if (modal.canceled) { return; }
      dp.events.add({
        start: args.start,
        end: args.end,
        id: DayPilot.guid(),
        text: modal.result
      });
    },

  };

  constructor(private ds: DataService) {
    this.landscape.addEventListener("change", ev => {
      this.viewUpdate();
    });
  }

  viewUpdate(): void {
    const isLandscape = this.landscape.matches;
    const isSmall = this.smallWidth.matches;

    if (isLandscape) {
      if (isSmall) {
        this.viewLandscape();
      }
      else {
        this.viewFull();
      }
    }
    else {
      this.viewPortrait();
    }
  }

  viewLandscape(): void {
    const w = window.innerWidth - (this.calendar.control.hourWidth || 0);

    this.config.columnWidthSpec = "Fixed";
    this.config.columnWidth = w / 3;
    this.config.viewType = "Week";
  }

  viewPortrait(): void {
    this.config.columnWidthSpec = "Auto";
    this.config.viewType = "Day";
  }

  viewFull(): void {
    this.config.columnWidthSpec = "Auto";
    this.config.viewType = "Week";
  }

  ngAfterViewInit(): void {
    this.viewUpdate();

    var from = this.calendar.control.visibleStart();
    var to = this.calendar.control.visibleEnd();
    this.ds.getEvents(from, to).subscribe(result => {
      this.events = result;
    });
  }

}

